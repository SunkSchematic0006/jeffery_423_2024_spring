print("hw")
