f = input("Enter a dollar amount: ")
j = float(f)/20 
twen = int(float(f/20))
print ("%20 bills:", twen)

