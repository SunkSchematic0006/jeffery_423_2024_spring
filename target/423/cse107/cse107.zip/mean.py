x = 0
g= 0
for k in range (10):
    g = input("enter data point")
    x = float(g) + float(x)


avg = x/(k+1)
print ("The average of these numbers is: ", avg)