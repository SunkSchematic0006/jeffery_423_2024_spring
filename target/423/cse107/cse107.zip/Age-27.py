Age = 80

if Age == 60:
   print ('Senior Discount')
elif 18 <= Age < 60:
   print ('No Discount')
else:
   print ('Junior Discount')
