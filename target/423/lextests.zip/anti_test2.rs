// Lexical error: Invalid identifier name with a dash
fn main() {
    let a-b = 10;
    let b = 20;
    let sum = a + b;
    println!("Sum: {}", sum);
}