fn main() { // Tests fn, and ops ((), {)
    enum nums { // Test invalid keyword
        one = 55,
        two,
        three
    }

    struct aStruct { // Invalid keyword
        aNumber: i32;
        aString: String;
    }

    let mut variable55_ = 10.55; // Tests let, mut, identifier, op, and real literal

    println!("a variable: {}!! // not a comment\n", variable55_); // Test string literal

    let num_bers = [1, 3, 7, 8, 5]; 
    for num_ber in num_bers.iter() {
        println!("       your number sir: {}", num_ber);
    }

    while i < 32 {
        println("i is not 32! {}\n", i);
        continue; // Invalid
    }

    loop { // Invalid
        println!("This will print forever");
    }    

}