// Lexical error: Invalid character in a real literal
fn main() {
    let pi = 3.1.4;
    println!("Value of pi: {}", pi);
}