//Allowed keywords in Irony.

static thing: bool = true;

fn main() {
    let result = true;
    let mut count = 10;
    while count > 0 {
        if count % 2 == 0 {
            result = false;
        } else {
            result = true;
        }
    }

    for n in 1..2 {
        break;
    }

    return 0;
}
