fn main() {
	// const THE_INT: &int 
	loop {
		if 4 < 5 {
			break;
		}
		else if 3 > 1 {
			println!("Value is relative");
		}
	}

	let foo = 9 as u8;

	const foo_bin : bool = true || true && !false;
	const foo_bin_comp1 : bool = (5 == 5) || (5 != 5) || (5 > 5) || (5 < 5);
	let foo_bin_comp2 = (5 >= 5) || (5 <= 5);

	foo_bin_comp2 |= (5 >= 5) || (5 <= 5);
	foo_bin_comp2 &= (5 >= 5) || (5 <= 5);
	foo_bin_comp2 <= (5 >= 5) || (5 <= 5);

	let foo_int = 2 + 1 - 9 + -3 * 2 / 6 ** 5;
	foo_int *= foo_int % 3;
	foo_int /= foo_int % 1;
	foo_int %= foo_int % 88282;
	foo_int ^= foo_int % 2;



}
