// This is the main function.
fn main() {
    // Statements here are executed when the compiled binary is called.

    	<Down><Up><Home>
    // Print text to the console.
    println!("Hello World!ꙮ");
    ꙮ
    
}
