

fn invalidTokens() {
    // keyword as
    let x = 'a';
    let y = x as i32;
}

// crate keywords
extern crate std as new_std
use new_std as newer_std

fn super_fetch() {}
mod frontend {
    pub fn fetch() {
        super::super_fetch
    }
}

// structs, impls, and traits

struct Hootinany {
    name: String,
    timestamp: u64,
}

trait When {
    fn when(self: Box<Self>) -> u64;
}

impl When for Hootinany {
    fn when(self: Box<Self>) -> u64 {
        return self.timestamp;
    }
}
