fn main() {
    for i in 1..=3 {
        for x in 1..3 {
            while true {
                if x != 2 {
                    break;
                }
            }
        }
    }
}
