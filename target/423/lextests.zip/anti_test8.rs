// Lexical error: Using an invalid character in an identifier
fn main() {
    let variable-name = "Example";
    println!("Variable Name: {}", variable-name);
}