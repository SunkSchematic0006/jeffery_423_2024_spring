let raw_string = br#"This is a raw string with special characters: \n \t"#;
println!("Raw String: {}", raw_string);