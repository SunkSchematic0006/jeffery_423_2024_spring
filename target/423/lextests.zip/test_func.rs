fn main() {
    test();
    test2(1);
}

fn test2(a: i64) -> Vec<str> {
    ["test"]
}

fn test() -> i64 {
    return 3;
}
