fn main() {
  let a = 5;
  let b = 2+a;
  let c = -b * 3;
  let d = c / 4;
  let e = d % 5;
  println!("Hello, CSE , 423);
}
