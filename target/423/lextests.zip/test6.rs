fn main() {
  let fact = 1;
  for let i in 2..10 {
    fact = i * fact;
  }
  println!("{}", fact);
}