fn main() {

    let mut n = 1000;

    
    while n > 1 {
        println!("{}", n);
        
        if n == 500 {
            println!("halfway there");
        } else if n % 2 == 1 {
            println!("test1");
        } else {
            println!("test2");
        }

        n -= 1;
    }
}