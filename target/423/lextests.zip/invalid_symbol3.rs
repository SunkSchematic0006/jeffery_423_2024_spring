bad_symbol : >>
