123
45.67
"Hello World"
let boolean = true;
let mut floating_point = 1.0;
/* should fail */
let integer = 0005; 