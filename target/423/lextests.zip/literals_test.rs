fn main() -> {
    //ints
    let mut a = 1;
    let b = 1;
    let c: i64 = 1;
    let mut c: i64 = 1;
    // floats
    let mut d = 1.2;
    let e = 1.2;
    let f: f64 = 1.2;
    let mut g: f64 = 1.2;
    // string
    let mut d = "test";
    let i = "test";
    let j: str = "test";
    let mut k: str = "test";
    // array
    let mut l = ["test"];
    let m = ["test"];
    let n: Vec<str> = ["test"];
    let mut o: Vec<str> = ["test"];
    // index
    let p = [1, 2];
    let q = p[0];
    // modify
    p += 1;
    p -= 1;
}
