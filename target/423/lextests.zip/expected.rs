// this file must compile and run exactly as it would using `rustc`

/* this is
 * a multi
 * line comment */

// functions are to be expected
fn loops() {
  let mut i = 0;
  // loop forever until we break
  loop {
    if i > 10 {break;}
  }

  let mut j = 0;
  // loop while true
  while j < 10 {
    j = j + 1;
  }

  // loop in through range
  // requires implementing `in` and `..` operations
  for k in 1..101 {
    println!("executing {}...", k);
    continue;
  }
  
  println!("oh \"goody\", this string has escaped values in it!");
}

fn alu() {
  if (true) {
    println!("true!");
  } else {
    println!("you may ask yourself: well, how did I get here!?");
  }
  
  return "shadow wizard cs gang; we love returning values.";
}

fn mathematics() {
  let mut x = 3;
  let mut y = -4;
  x + y;
  x - y;
  x * y;
  x / y;
  x += y;
  y -= x;
  y = y % x;
  x = 33.5;
  y = -123.7;
}

fn main() {
  alu();
  mathematics();
  loops();
}
