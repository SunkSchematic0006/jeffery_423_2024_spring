fn main() {
    let s = unterminated string";
    println!("Hello, world!");
}