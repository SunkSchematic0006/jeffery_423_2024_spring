fn main() {
    let a = 4;
    let b = 5;
    let mut ans: i32;
    let mut and: bool;

    ans = a + b;
    println!("Ans: {}", ans);
    ans = a - b;
    println!("Ans: {}", ans);
    ans = a * -b;
    println!("Ans: {}", ans);
    ans = a / b;
    println!("Ans: {}", ans);
    ans += a;
    println!("Ans: {}", ans);
    ans -= b;
    println!("Ans: {}", ans);
    ans = a % b;
    println!("Ans: {}", ans);

    and = a == b;
    println!("Ans: {}", and);
    and = a != b;
    println!("Ans: {}", and);
    and = a > b;
    println!("Ans: {}", and);
    and  = a < b;
    println!("Ans: {}", and);
    and = a >= b;
    println!("Ans: {}", and);
    and = a <= b;
    println!("Ans: {}", and);
    and = (a != 0) && (b != 0);
    println!("Ans: {}", and);
    and = (a != 0) || (b != 0);
    println!("Ans: {}", and);
    and = !(a != 0 || b != 0);
    println!("Ans: {}", and);

    ans = a >> b;
    println!("Ans: {}", ans);
    ans = a << b;
    println!("Ans: {}", ans);
    ans = a | b;
    println!("Ans: {}", ans);
    ans = a & b;
    println!("Ans: {}", ans);
    ans = a ^ b;
    println!("Ans: {}", ans);
    ans &= b;
    println!("Ans: {}", ans);
    ans |= a;
    println!("Ans: {}", ans);
    ans ^= b; 
    println!("Ans: {}", ans);
    ans <<= 1; 
    println!("Ans: {}", ans);
    ans >>= 1; 
    println!("Ans: {}", ans);
    ans = !a;
    println!("Ans: {}", ans);

    ans ==== a;

     // Garbage
     + 
     >>
     #
}
