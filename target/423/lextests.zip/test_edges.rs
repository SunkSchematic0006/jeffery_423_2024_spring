// This is a comment
(/* This is a multi-line comment */)

😀
🚀
'é, ü, ñ' 
д, ж
(ع, م)
(汉字).

                let  x          = null;
let mut x.  xxxx = 0;
an_unterminated_str = 'cjlvfvdfmkjfewdfnjkgkbkb...