"this is a good string :)"
"this is a " bad string :("
"this is a valid
Rust string, but possibly not
a valid Irony string"
"a string containing le funnie symbols 🥸🥺🍄"
"this is the string that never ends! yes it goes on and on my friends!
