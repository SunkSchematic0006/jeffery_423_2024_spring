/// headder 
// nothin much
fn main(){
    let mut _TESTVAR_double = 0.99;
    let _kkz99_int = 0;
    let _a_sd = 0.;
    let _a_sd = .0;
    let _test_char_capture = '\'';
    let _test_cha3r_capture_2 = '5';
    let _garbage_as_string = "‰"; 
    let multi_line_string = "
    
    
    
    asdf
    asdf
    asdf
    
    ";
    "asdf""asdf"
}