// Lexical error: Adding an invalid character to an integer literal
fn main() {
    let decimal_integer = 42abc;
    println!("Decimal Integer: {}", decimal_integer);
}