// Lexical error: Misplaced exclamation mark
fn main() {
    let is_true! = true;
    let is_false = false;
    println!("is_true: {}, is_false: {}", is_true, is_false);
}