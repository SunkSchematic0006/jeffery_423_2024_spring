// This code implements every keyword in Rust that is in Irony

// Uncomment the following line to get rid of rustc warning (comment it for the fec compiler)
//#[allow(dead_code)]

// Test the keyword "enum"
enum TestEnum{
    Good,
    Bad,
    Ugly,
    Grotesque
}

// Test the keyword "struct"
struct Point{
    x: i32,
    y: i32
}


// Test the keyword "impl"
impl Point{
    fn new(x: i32, y: i32) -> Point{
        Point{x: x, y: y}
    }

    fn get_x(&self) -> i32{
        self.x
    }

    fn get_y(&self) -> i32{
        self.y
    }
}

extern crate std as other_std; // Test the keywords "extern" and "crate"
fn main(){
    // Test the keyword "as"
    let x = 'a';
    let y = x as i32;
    if y == 97 {
        // Of course this works. 
        println!("The keyword 'as' works!");
    }
    else {
        println!("The keyword 'as' does not work!");
    }

    // Test the keywords "loop", "break", "continue", "while", "for" and "in"
    let mut x = 0;
    loop {
        x += 1;
        if x == 10 {
            break;
        }
    }
    while x > 0 {
        x -= 2;
        if x % 3 == 0 {
            continue;
        }
        x += 1;
        println!("{}", x);
    }
    for i in 0..10 {
        x += i;
    }

    // Test the keywords "true" and "false
    if (true && false) || (true || false) {
        println!("The keywords 'true' and 'false' work!");
    }
    else {
        println!("The keywords 'true' and 'false' do not work!");
    }

    const CONST_TEST: i32 = 42;
    if CONST_TEST < 42 {
        return
    }

    let p1: Point = Point::new(1, 2);

    println!("p1: x{} y{}", p1.get_x(), p1.get_y());

    let self_confidence = TestEnum::Good;

    // Test the keyword "match"
    match self_confidence {
        TestEnum::Good => println!("I am good"),
        TestEnum::Bad => println!("I am bad"),
        TestEnum::Ugly => println!("I am ugly"),
        TestEnum::Grotesque => println!("I am grotesque")
    }
}
