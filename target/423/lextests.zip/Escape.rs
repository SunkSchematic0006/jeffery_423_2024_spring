fn main() {
    println!("Here we have a newline\n");
    println!("And now a tab\t");
    println!("Return to start\rhere we go");
    println!("Heres a single quote \'");
    println!("And a double \"");

    println("unterminated!)
}