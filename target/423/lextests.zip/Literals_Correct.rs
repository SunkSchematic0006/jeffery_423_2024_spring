//Attempt at comprehensive correct literals for Irony.
// The other correct literal is in Ops_Punc_COrrect.rs with the colon type designation.

fn main() {
    let integer0 = 1;
    let integer2 = 1i32;
    let integer3 = 2u32;
    let integer1 = 1u8;
    let integer2 = 1i8;
    let integer3 = 1u16;
    let integer4 = 1i16;
    let integer5 = 1u32;
    let integer6 = 1i32;
    let integer7 = 1u64;
    let integer8 = 1i64;
    let integer9 = 1u128;
    let integer10 = 1i128;
    let integer11 = 1usize;
    let integer12 = 1isize;
    let funnyinteger = 00100;

    let pi = 3.14;
    let one = 001.0;
    if (!true) == false {
        printf!("Hello,\t\"Rustaceans\".");
        printf!("\'Wumbo\' is coming to \\ get \\ us.")
        printf!("Waiter! Waiter! More escape characters please!")
        printf!("this is a tab \t wow that was cool heres a carriage return \r wow!!! that was cool.")
        printf!("`1234567890-=qwertyuiop[]asdfghjkl;\\zxcvbnm,./~!@#$%^&*()_+QWERTYUIOP{}ASDFGHJKL:\"|ZXCVBNM<>?\t\n\r")
        //secret guy \n \t \r \" \' \\
    }
}
