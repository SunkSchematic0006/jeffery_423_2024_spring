fn main() {

    let test1 = 1 + 5;
    let test2 = 6 * 2.5;
    let test3 = 5 ** 2;
    let test4 = 6 - "test";
    let test1 -= 5;
    let test1 += 9;
    let test5 = 8 + (-1);
    let test6 = 9 % (-5);
    let test7 = 8 % 4;
    let test8 = 8 % 100;
    let test9 = -500;
}