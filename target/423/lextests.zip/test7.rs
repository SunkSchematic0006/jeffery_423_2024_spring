fn main() {
    let last = 1;
    let fib = 1;
    let i = 0;

    while i < 10 {
      let a = fib;
      let fib += last;
      let last = a;
      i += 1;
    }

    println!("{}", fib);
}
