fn main() {
	println!("Hello, CSE {}\n", 423);
	println!("This is a test \" \n\" \" string");
	println!("This is a multiline thingy \
			string");
	println!("This is another multiline 
			string, now with tabs!");


	println!(" this ' is a string with a single quote");
	println!(" this \" is a bad string");
	println!(" this \" is a bad string");
	// println!(' this " is a string with a double quote');
	
	// const THE_INT: &int 
	let n = 3;
	while 1 < n {
		if 4 < 5 {
			break;
		}
		else if 3 > 1 {
			println!("Value is relative");
		}
	}

	let mut foo_bin  = true || true && !false;
	let mut foo_bin_comp1 = (5 == 5) || (5 != 5) || (5 > 5) || (5 < 5);
	let mut foo_bin_comp2 = (5 >= 5) || (5 <= 5);

	foo_bin_comp2 |= (5 >= 5) || (5 <= 5);
	foo_bin_comp2 &= (5 >= 5) || (5 <= 5);

	let mut foo_int = 2 + 1 - 9 + -3 * 2 / 6 ** 5;
	foo_int += foo_int % 2;
	foo_int -= foo_int % 9;
	foo_int *= foo_int % 3;

	let mut int_1 = 33333;
	let mut float_2 = 3.9;
	let mut float_3 = 3.0;
	let mut float_4 = 3.;
	// let mut float_5 = .8;
	// let mut float_6 = .;



}
