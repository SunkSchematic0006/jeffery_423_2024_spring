fn main() {

	println!("should be seen");
	"// testing potential comment grabber"
	"/n test"
	"/0 test"
	'v'
	'/'

	
	
	println!(" this may be seen " testing " testing ");
	println!("return 1" return 5, "ok ok ");
	println!(""bad string "");
	println(""another bad string");
	
	"" this string is not terminated /n 
	
	
}

