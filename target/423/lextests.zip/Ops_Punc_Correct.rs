//Correct uses of operators and punctiation in Irony.

fn main() {
    let mut count = 10;
    let forty_two: i32 = 42;
    count += 3;
    count -= 42;
    
    let mut result = 10 + 5 * 2 / (3 - 7); //comment about this crazy math
    result = result ** (count % 10)
 
    let equal = (-3 + 8) == 5;
    let not_equal = (3 + 2) != 5;
    let greater_than = (3 > 2);
    let less_than = (5 < 6);
    let greateq_than = (5 >= 2);
    let lesseq_than = (6 <= 6);

    let andres = true && true;
    let orres = true || false;
    let notres = !true;

    let exclrange = 1..5;

    let array = [10, 20];   

}
