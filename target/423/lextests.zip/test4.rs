fn main() {
    let num123 = 123 << 2;
    println!("{}", num123);
    println!("Test\n\t\t \\\"Hello world\"\\");
}
