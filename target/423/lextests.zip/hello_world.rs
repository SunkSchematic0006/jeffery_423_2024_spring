/// headder 
/// nothin much
fn main() {
    println!("Hello, CSE {}", 423);
    let mut _TESTVAR = 0.99;
    let _kkz99 = 0;
    //let 99k = 5; test invalid variable name
    //let _Àfter = '\n'; //TODO allow for accented charachter variable names
    //‰‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰ ‰  //test garbage
    if  _TESTVAR<=5.{
        _TESTVAR = 9.;
    }
    let _test_char_capture = '\'';
    let _garbage_as_string = "‰"; //test garbage as a string
    //let _ahh2 = 'à';//TODO understand how this does not work


    
    //'' empty char
    //' unmatched char
    //" unmatched string
    let multi_line_string = "
    
    
    
    asdf
    asdf
    asdf
    
    ";

    // ! @ # $ % ^ & * ( ) - _ = + [ ] { } \ | ; : , < . > / ? ~ ` << >> <= == != >= && || <<= >>= -= &= |= += *= /= ^= %= .. ... :: -> <- => // Test individual chars
    // as break const continue crate else enum extern false fn for if impl in let loop match mod move mut pub ref return Self self struct super trait true type unsafe use where while async await abstract become box do final macro override priv typeof unsized virtual yield try macro_rules union static dyn 

    /* /954*6 MULTI LINE COMMENT 1

    5613-* ****** ** 
    * 

    * 5
6514
‰
*/

    /* /954*6 MULTI LINE COMMENT 2

    5613-* ****** ** 
    * 

    * 5
6514
‰
****/
}

/*async fn foo() -> u8 { 5 }

fn bar() -> impl Future<Output = u8> {
    // This `async` block results in a type that implements
    // `Future<Output = u8>`.
    async {
        let x: u8 = foo().await;
        x + 5
    }
}*/