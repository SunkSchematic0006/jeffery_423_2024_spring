fn main() {

    let srt1 = "this is a string that works";

    let static = "does not work";
    let for = "does not work";

    let test2 = "test \\\\" does not work";

    let test2 = "test \\\\n does not work";

    let test2 = "test \\"" does not work";
}