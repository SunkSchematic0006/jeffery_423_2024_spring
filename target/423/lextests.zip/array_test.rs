fn main() {
    
    let arr1: [i32; 5] = [1, 2, 3, 4, 5];
    let arr2: [i32; 500] = [0; 43];
    let empty_array: [u32; 0] = [];
    let arr3: [u32; 0] = [5,6,7];
    let arr4 = [8, 9, 10];

    println!("First element: {}", arr1[0]);
    println!("Second element: {}", arr1[1]);
    println!("Third element: {}", arr1.2);


    for i in 0..arr1.len() { // Oops, one element too far!
        println!("{}: {}", i, arr1[i]),
    }


}