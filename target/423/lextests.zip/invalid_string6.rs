fn main() {
    let ascii_string = "Hello, \x57orld!";

    println!("ASCII String: {}", ascii_string);
}
