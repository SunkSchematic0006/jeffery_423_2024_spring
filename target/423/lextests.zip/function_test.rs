fn main() {
    println!("this is a test:{}", function(72, 'a'));
}

fn function(number: i32, character: char)-> i32 {
    let ret = number + 3;

    println!("num: {number} char: {character}");
    
    return ret;
}