fn main() {
	let mut var = 10;
	
	if var < 0 {
		println!("should not happen {}", var);
	}
	else if var == 10 {
		println!("The variable is equal to 10");
	}
	else if var == 20 {
		println!("shouldn't see this");
	}
	else {
		var = 20;
	}
	
	while var == 20 {
		println!("Entered loop");
		break;
	}
	
	let test = true;
	while test {
		println!("true works");
		break;
	}
	for x in 1..=10 {
		println!("{}", x);
	}
	let test2 = false;
	
	static bar: [i64; 3] = [4, 5, 6];
	return test2;


}
