// Lexical error: Invalid character in an identifier
fn main() {
    let x@ = 5;
    let y = 5;
    if x == y {
        println!("x is equal to y");
    } else {
        println!("x is not equal to y");
    }
}