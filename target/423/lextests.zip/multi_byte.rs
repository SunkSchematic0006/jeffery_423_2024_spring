fn main() {
    println!("{}", true && false); // Uses &&
    println!("{}", true || false); // Uses ||
    println!("{}", [1, 2, 3][0]); // Uses []
}