fn main() {
    println!("Integer: {}", 42); // Integer
    println!("Float: {}", 3.14); // float
    println!("Boolean: {}", true); // Boolean
    println!("String Literal: {}", "Hello, Worlds!"); // String
    println!("Escaped String: {}", "Line break: \n Tab: \t Single Quote: \' Double Quote: \" Backslash: \\"); // Escape characters
}
