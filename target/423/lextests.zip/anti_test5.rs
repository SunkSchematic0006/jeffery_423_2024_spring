// Lexical error: Missing value after decimal
fn main() {
    let pi = 3.;
    println!("Value of pi: {}", pi);
}