//invalid variable name
let 99k = 5;