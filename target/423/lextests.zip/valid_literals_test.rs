fn main(){
    let valid_string1: String= "\'Hello,\nDr.\tJ'";
    let valid_string2: str = "\"Double Quotes\"";
    let valid_string3: str = "Carrage \r Return";
    let valid_string4: String = "";
    let valid_string5: String = " ";


    let integer1: i8 = 1; 
    let integer2: i16 = 11; 
    let integer3: i32 = 111; 
    let integer4: i64 = 1111; 

    let integer1: u8 = 2; 
    let integer2: u16 = 22; 
    let integer3: u32 = 222; 
    let integer4: u64 = 2222; 

    let float1: f32 = 1.1; 
    let float2: f64 = 22.22; 

    let _unsused_variable: i16 = 213; 

    
    println!("hi");
}