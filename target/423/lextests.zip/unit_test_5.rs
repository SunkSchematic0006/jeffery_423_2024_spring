//overfull char
'n\n' 
'\nn' 
'\'\'' 
//empty char
''