fn main() {
    // this is an Irony comment, override is an illegal Irony keyword
    // during testing, different lines (that cause lexical errors) are commented out to test all cases
    println!("This is terminal output.\n");
    let mut objct = "laptop";
    let flt1 = 2.124;
    let int1 = 77;
    let nt2 = 100;
    if (int1 < nt2 && true) {
        println!("int1 is less than \"nt2.\n");
    }
    let mut mult = int1 * nt2;
    mult += int1;
    objct = "computers";
    println!("55run {}", flt1);
    let 66illegalname = "broken";
    let _hello = "hi";
    let compilers = 423; 
    println!("first string literal", " with the second string literal");
    println!("str literal with operators\" 1***2=2, // < > & | ! -= ", _hello);
    //println!("str lit with escape characters \" \'\n\r\t\"");
    let string1 = "bad escape \g\:";
    while (true) {
    //    extern box loop;
    //    virtual;
    }
    //as
    //async
    //await
    //abstract
    //become
    //box
    //continue
    //crate
    //do
    //dyn
    //enum
    ~
    <<
    >>
    &=
    |
    ^=
    >>=
    <<=
    &
    ^
    *=
    /=
}
