/* Tim S. Salazar IV
   Lab2: Flex Testing
   CSE 4023
   02/2/2024 
   Test for non-trivial tokens literal types
   */

    fn main() {
        // raw string literal
        let raw_string_literal = r#"Hello World, Here is a raw "string" literal\n."#;

        // byte char literal 
        let byte_char_literal = b'A';

        // byte string literal
        let byte_string_literal = b"Hello, World!";

        println!("Raw String Literal: {}", raw_string_literal);
        println!("Byte Char Literal: {}", byte_char_literal);
        println!("Byte String Literal: {:?}", byte_string_literal);
    }


