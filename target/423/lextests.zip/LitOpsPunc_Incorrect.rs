//Incorrect Irony usage of Literals, Operators, and punctuation.

fn main() {
    let mrOctal = 0o467;
    let baddec1 = 1.;
    let baddec2 = .1;
    let mut a = 0x27;
    let mut b = 0b0101;
    let mut result = ~a;
    result = a << 2;
    result = a >> 2;
    result = a &= b;
    result = a |= b;
    result = a ^= b;
    result = a >>= 2;
    result = a <<= 2;
    result = a & b;
    result = a | b;
    result = a ^ b;

    printf!("fec\xA9 is the best compiler \
there is.");

    
}
