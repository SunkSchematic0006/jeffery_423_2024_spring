fn main() {
    let _ab = !false;
    let _0a = 0x0a;
}
