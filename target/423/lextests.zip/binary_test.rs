fn main() {

    let test1 = 6 < 4;
    let test2 = 7 > "hi";
    let test3 = 5 <= 6.4;
    let test4 = 5 <= 3;
    let test5 = !test1;
    let test6 = !false;
    let test7 = false && true;
    let test8 = true || test4;
    let test9 = true &&|| false;
}