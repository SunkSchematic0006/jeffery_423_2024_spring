/* Tim S. Salazar IV
   Lab2: Flex Testing
   CSE 4023
   02/2/2024 
   Test for Regular Tokens literal types
   */

   fn main() {
      // Int literal
      let integer_literal = 159;
      // Float literal
      let float_literal = 2.71;
      // String literal
      let string_literal = "Hello, World!";   
      // Char literal
      let char_literal = 'c';
      // Boolean literal
      let boolean_literal = true;
      // Escape literal
      let escape_literal = "\n";
   
      // Print the literals
      println!("Integer Literal: {}", integer_literal);
      println!("Float Literal: {}", float_literal);
      println!("String Literal: {}", string_literal);
      println!("Char Literal: {}", char_literal);
      println!("Boolean Literal: {}", boolean_literal);
      println!("Escape Literal: {}", escape_literal);
   }
   