let invalid_string1: String = "Invalid  string; 

