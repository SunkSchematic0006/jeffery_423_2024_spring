// single_byte_tokens.rs
fn main() {
    //comment test /test //
    println!("Hello, world!"); // Uses (), ;, and "
    //println!("Hello, world!");
}
