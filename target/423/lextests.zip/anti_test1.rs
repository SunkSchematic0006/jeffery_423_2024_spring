// Non-keywords example
struct ExampleStruct {
    value: i32,
}

fn main() {
    let instance = ExampleStruct { value: 42 };
    println!("Instance value: {}", instance.value);
}