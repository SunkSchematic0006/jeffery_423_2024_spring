// The goal of this program is to test the behavior of
// my lexical analyzer when it encounters weird input
fn main(){
    let str1 = String::from("Hello,\n \"World!\""); // This string is LEGAL
    let str2 = String::from("Hello, \tWorld!"\""); // This string is ILLEGAL
    let str3 = String::from("Hello, \tWorld!\""); // This string is LEGAL
    let str4 = String::from("Hello,
What is up?
How goes it?"); // This string is legal by rust but doesnt have to be legal in Irony.
    let str\n5 = String::from("Hello, World!"); // The variable name is illegal
}