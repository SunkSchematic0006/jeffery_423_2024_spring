fn main(){
    // First we will print the string "Hello, World!"
    println!("Hello, World!");

    let charLit = 'a'; // Test character literal
    let charLit2: char = '\''; // Test character literal with escaped char

    // Lets declare a variable
    let l = 1;
    // Lets declare a variable with a type annotation
    let m: i32 = 2;
    // Lets declare a variable with a mutable binding
    let mut n = 3;

    // Lets do some basic arithmetic
    let x = 1 + 5; // Test addition
    let y = x * 390; // Test multiplication and using a variable
    let z = y / 5; // Test division 
    let b = z - x; // Test subtraction

    // Lets do some basic boolean operations
    let b = true; // Test boolean (and shadowing)
    let c: bool = false; // Test boolean with type annotation
    let d = b && c; // Test logical AND
    let e = b || c; // Test logical OR
    let f = !b; // Test logical NOT

    // Now we will iterate through the prime numbers.
    let mut x = 4; // We will start at 4
    loop {
        // We will check if x is prime
        if is_prime(x) {
            println!(); // We will print a newline
            // If x is prime, we will print it
            println!("{} is prime", x);
        }
        print!("{}, ", x);
        // We will increment x by 1
        x += 1;
        if x > 420 {
            break;
        }
    }
    println!();

    // Lets play with Strings
    /* Note: You will have to comment out some of these lines, as we are not implementing Rust pointers */
    let s = "Hello, World!"; // Test string literal
    println!("{}", s); // Test printing a string literal
    let t: &str = "Hello, World!"; // Test string literal with type annotation
    let u = String::from("Hello, World!"); // Test string object
    println!("{}", u); // Test printing a string object
    let v: String = String::from("Hello, World!"); // Test string object with type annotation
    let w = s.to_string(); // Test converting a string literal to a string object
    let x: &str = &u; // Test converting a string object to a string literal

}

fn is_prime(x: i32) -> bool {
    // We will iterate through all the numbers from 2 to x
    let max = x / 2; // We only need to check up to half of x (technically, we only need to check up to the square root of x, but this is simpler for now)
    for i in 2..max {
        // If x is divisible by i, then it is not prime
        if x % i == 0 {
            return false;
        }
    }
    // If x is not divisible by any number from 2 to x, then it is prime
    return true;
}