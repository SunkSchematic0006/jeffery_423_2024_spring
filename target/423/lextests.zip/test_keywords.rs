fn keywords() {
    let variable = 10;
    if variable > 5 {
        println!("Greater");
    } else {
        println!("Smaller");
    }

    let _ = await some_future;

    dyn trait ExampleDyn {
    }

    abstract class ExampleAbstract {
    }

    become leader;
}





