fn​main() { //no space between fn and main
    println!("Hello,​world!"); // string no space
}