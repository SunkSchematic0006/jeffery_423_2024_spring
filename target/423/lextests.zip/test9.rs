// Keywords example
fn main() {
    let condition = true;
    if condition {
        println!("This code executes because of the 'if' keyword");
    } else {
        println!("This won't be executed");
    }
}