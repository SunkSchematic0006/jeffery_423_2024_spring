// Escape characters example
fn main() {
    // Using escape character to include a newline in the string
    let message = "Hello, Rust!\nWelcome to the world of escape characters.";

    // Printing the string with newline
    println!("{}", message);

    // Using escape character to include a tab in the string
    let tabbed_message = "This\tis\ta\ttabbed\tmessage.";

    // Printing the string with tabs
    println!("{}", tabbed_message);
}