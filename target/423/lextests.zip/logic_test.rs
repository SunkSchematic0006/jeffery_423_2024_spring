fn main() {
    let x = 5;
    let f = false;
    let t = true;
    if x < 1 {
        println!("less than");
    } else if x > 1 {
        println!("greater than");
    }
    if x == 5 {
        println!("same as");
    } else if x != 5 {
        println!("not equal");
    }
    if x >= 4 {
        println!("geq");
    }
    if x <= 6 {
        println!("leq");
    }
    if f && t {
        println!("AND");
    } else {
        println!("AND1");
    }

    if f || t {
        println!("OR");
    }

    if t && !f {
        println!("NAND");
    }
}
