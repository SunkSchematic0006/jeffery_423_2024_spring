let binary_literal = 0b10101010101;
