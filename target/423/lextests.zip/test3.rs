fn main() {
  let b = false;
  let c = false;
  // This is a number
  let d = 5;
  if (d == 5 && b != false || d + 2 < 2) {
    c = !b;
    await some_async_func(d);
  }
}