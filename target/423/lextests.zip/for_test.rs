fn main() {

    for n in 1..50 {
        if n % 2 == 0 {
            println!("even");
        } else {
            println!("odd");
        }

        if n > 25 {
            break;
        }
    }
}