// non-string literals

// == integer literals == //

12 // valid
1234 // valid
12345678901234567890 // this is an invalid u32/i32, but a valid u64/i64
12345678901234567890123 // cannot be stored in 64 bits

-69 // valid
6-9 // i mean, this is valid, but not a literal

123_456_789 // Rust allows for adding underscores to integer literals

// == float literals == //

0.0 // valid
0.1 // valid

.1 // invalid
12. // invalid

-69.420 // valid
-7.0 // valid
-. // invalid

- 17.20 // valid, but two tokens

// == character literals == //

'a' // valid
'6' // valid
'\n' // valid

'' // invalid

'🤡' // this would be valid in Rust, but is not valid in Irony
'\x00' // this would be valid in Rust, but is not valid in Irony
'\u4201' // this would be valid in Rust, but is not valid in Irony
