/* Tim S. Salazar IV
   Lab2: Flex Testing
   CSE 4023
   02/2/2024 
    Random, bad, weird, cases
   */

fn main(){
    // random chars
    let random_chars = "@#$%^&*()_+";
    println!("Random Chars: {}", random_chars);
    // Syntax
    let test _syntax = if (true, {println!("Hello, World!")});

    println!("Random Chars: {}", random_chars);

    /* these test are suppose to fail due to bad syntax and bad escape */
    /*
    
    // bad syntax
    let bad_syntax = if (true) {println!("Hello, World!, missing closing bracket");
    println!("Bad Syntax: {}", bad_syntax);

    // Bad String
    let bad_string = "This string does not have an end;
    println!("Bad String: {}", bad_string);
    */
}