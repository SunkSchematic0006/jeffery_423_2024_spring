int othermain(int argc, char **argv) {
    printf("Goodbye World!");

    return 0;
}
