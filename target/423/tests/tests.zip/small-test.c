int main() {
  char *s, b;
}

int test(int b, char c) {
  b = c;
}
