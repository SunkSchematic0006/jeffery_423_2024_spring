int foo(int x, char *y) {
   return x;
   }

int main()
{
   int z;
   z = foo(5, "funf");
   return 0;
}
