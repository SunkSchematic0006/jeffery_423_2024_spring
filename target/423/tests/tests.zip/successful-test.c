/**
 * this is a test file 
 *
 * For the lexer
 */

/*
 * different multiline
 */

/**/

/*
    some other one
   */

// some one line comments
// another one

// ploopie

// This currently doesn't work
// #include "tests/other-successful-test.c"

int main(int argc, char **argv) {
    printf("Hello\tWorld!\n");

    for (i = 0; i < 10; i++) {
        printf("i: %d\n", i);
    }

    return 0;
}
