/**
 * this is a test file 
 *
 * For the lexer
 */

/*
 * different multiline
 */

/**/

/*
    some other one
   */

// some one line comments
// another one

// ploopie

int main(int argc, char **argv) {
    char *a = test";

    printf("Hello World!, %s\n", a;

    return 0;
}
