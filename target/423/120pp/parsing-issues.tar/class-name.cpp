


class bar {

};

int main(){

  bar x;

}
