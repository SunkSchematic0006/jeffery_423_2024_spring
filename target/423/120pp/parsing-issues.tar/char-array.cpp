

int main(){

   char b[10][10];

   b[0] = { 'e','v','e','r','y' };

   return 0; 
}
