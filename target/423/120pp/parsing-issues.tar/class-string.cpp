


class bar {
     string name;	
};
