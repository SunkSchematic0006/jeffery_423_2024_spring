
class Foo{
public:
   Foo();   
   int play();
};

Foo::play(){
  return 0;
}
