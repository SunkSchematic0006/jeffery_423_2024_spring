


int main(){

  string name;	

}
